#Hypergraph Toolbox: HyperG
A toolbox for hypergraph including edge construction, graph construction and graph/hypergraph convolution.